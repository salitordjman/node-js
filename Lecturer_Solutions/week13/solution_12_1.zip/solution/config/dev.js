module.exports = {
  WEATHER_API: "d6a84b552ca1a65234cbea2816953c8c",
  GEO_API:
    "pk.eyJ1IjoicGluaTg1IiwiYSI6ImNrajJqNXR3bTU3N3oyeXFqOTZsejlhYWkifQ.UfBv0pMkYVh1fAhE923ItA",
};
