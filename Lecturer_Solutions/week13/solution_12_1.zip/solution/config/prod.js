module.exports = {
  WEATHER_API: process.env.WEATHER_API,
  GEO_API: process.env.GEO_API,
};
